package com.job.tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
